# MultiDigitCalc

Probably the most inefficient way to make a calculator, but its a kinda cool terminal tool.

Copyright (C) 2025

#Usage

1. download the zip file
2. download python
3. run calc file

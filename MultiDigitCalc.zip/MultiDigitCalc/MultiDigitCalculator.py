import sys

def FindMode():
    TwoOrThreeDigits = str(input("Three or Two Digits? Type 'Two' or 'Three': "))

    if TwoOrThreeDigits == "Two" or TwoOrThreeDigits == "two":
        TwoDigitMode()

    if TwoOrThreeDigits == "Three" or TwoOrThreeDigits == "three":
        ThreeDigitMode()


def TwoDigitMode():
    number1 = int(input('1st Number: '))
    symbol = str(input('Add(+), Subtract(-), Multiply(*), or Divide(/): '))
    number2 = int(input('2nd Number: '))

    def DivError():
            sys.exit("Can not divide by 0")
            restart = str(input("Restart Calculator? y/n"))

            if restart == "n" or restart == "N":
                sys.exit("Bye!")
            
            if restart == "y" or restart == "Y":
                FindMode()

    if symbol == "/":
        if number1 == 0:
            DivError()
        if number2 == 0:
            DivError()

    if symbol == "+":
        print(number1 + number2)

    if symbol == "-":
        print(number1 - number2)

    if symbol == "*":
        print(number1 * number2)

    if symbol == "/":
        print(number1 / number2)

def ThreeDigitMode():
    number1 = int(input("1st Number: "))
    symbol1 = str(input("Add(+), Subtract(-), Multiply(*), or Divide(/): "))
    number2 = int(input("2nd Number: "))
    symbol2 = str(input("Add(+), Subtract(-), Multiply(*), or Divide(/): "))
    number3 = int(input("3rd Number: "))

    def DivError():
        sys.exit("Can not divide by 0")

        restart = str(input("Restart Calculator? y/n"))

        if restart == "n" or restart == "N":
            sys.exit("Bye!")

        if restart == "y" or restart == "Y":
            FindMode()


    if symbol1 == "/":
        if number1 == 0:
            DivError()

        if number2 == 0:
            DivError()

        if number3 == 0:
            DivError()

    if symbol2 == "/":
        if number1 == 0:
            DivError()
        
        if number2 == 0:
            DivError()

        if number3 == 0:
            DivError()


    if symbol1 == "+" and symbol2 == "+":
        print(number1 + number2 + number3)

    if symbol1 == "+" and symbol2 == "-":
        print(number1 + number2 - number3)

    if symbol1 == "+" and symbol2 == "*":
        print(number1 + number2 * number3)
    
    if symbol1 == "+" and symbol2 == "/":
        print(number1 + number2 / number3)

    if symbol1 == "-" and symbol2 == "+":
        print(number1 - number2 + number3)

    if symbol1 == "-" and symbol2 == "-":
        print(number1 - number2 - number3)

    if symbol1 == "-" and symbol2 == "*":
        print(number1 - number2 * number3)

    if symbol1 == "-" and symbol2 == "/":
        print(number1 - number2 / number3)

    if symbol1 == "*" and symbol2 == "+":
        print(number1 * number2 + number3)

    if symbol1 == "*" and symbol2 == "-":
        print(number1 * number2 - number3)

    if symbol1 == "*" and symbol2 == "*":
        print(number1 * number2 * number3)

    if symbol1 == "*" and symbol2 == "/":
        print(number1 * number2 / number3)

    if symbol1 == "/" and symbol2 == "+":
        print(number1 / number2 + number3)

    if symbol1 == "/" and symbol2 == "-":
        print(number1 / number2 - number3)

    if symbol1 == "/" and symbol2 == "*":
        print(number1 / number2 * number3)

    if symbol1 == "/" and symbol2 == "/":
        print(number1 / number2 / number3)



FindMode()

    